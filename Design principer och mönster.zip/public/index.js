var socket = io()


// function addCourse() {
//     socket.emit("addCourse", "")
// }
// socket.on("addCourse", (msg) => {
//     console.log(msg)
// })
